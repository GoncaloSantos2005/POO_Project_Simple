﻿/*
*	<copyright file="TrabalhoPOO_Simples.cs" company="IPCA">
*		Copyright (c) 2024 All Rights Reserved
*	</copyright>
* 	<author>gonca</author>
*   <date>12/2/2024 11:13:59 AM</date>
*	<description></description>
**/
using System;
using System.Collections.Generic;
using ProjectException;
using ObjetosNegocio;
using DadosNegocio;

namespace TrabalhoPOO_Simples
{
    /// <summary>
    /// Purpose:
    /// Created by: gonca
    /// Created on: 12/2/2024 11:13:59 AM
    /// </summary>
    /// <remarks></remarks>
    /// <example></example>
    public static class Medicos
    {
        #region Attributes
        static List<Medico> medicos = new List<Medico>();
        static int contador=0;
        #endregion

        #region Methods

        #region Properties
        #endregion

        #region Overrides
        #endregion

        #region OtherMethods
        /// <summary>
        /// Retorna todos os médicos da lista.
        /// </summary>
        /// <returns>Lista de objetos <see cref="Medico"/>.</returns>
        public static List<Medico> ObterTodos()
        {
            return medicos;
        }

        public static int AdicionarMedico(Medico medico)
        {
            int resultado = ValidarMedico.ValidarObjetoMedico(medico);
            if (resultado != 1)
                throw new ListaMedicosException("Médico não adicionado", resultado);
            
            resultado = ValidarListaMedicos.VerificarCRMDuplicado(medico.CRM);
            if (resultado != 1)
                throw new ListaMedicosException("Médico não adicionado", resultado);

            medicos.Add(medico);
            contador++;
            return resultado;
        }

        public static int RemoverMedico(int crm)
        {
            try
            {
                medicos.Remove(FindMedico(crm));
                contador--;
            }
            catch (ListaMedicosException ex) 
            {
                throw ex;
            }
            return 1;
        }

        public static int AtualizarMedico(Medico medicoAtualizado)
        {
            try
            {
                Medico medico = FindMedico(medicoAtualizado.CRM);
                medico.Nome = medicoAtualizado.Nome;
                medico.DataN = medicoAtualizado.DataN;
                medico.NIF = medicoAtualizado.NIF;
                medico.Morada = medicoAtualizado.Morada;
                medico.Especialidade = medicoAtualizado.Especialidade;
            }
            catch (ListaMedicosException ex)
            {
                throw ex;
            }
            return 1;
        } 

        private static Medico FindMedico(int crm)
        {
            int res;
            try { 
                res = ValidarMedico.ValidarCRM(crm);
                if (res != 1)
                    throw new ListaMedicosException("Não foi possível encontrar o Médico", res);
                Medico medico = null;

                foreach(Medico m in medicos)
                {
                    if (m.CRM.Equals(crm))
                    {
                        medico = m;
                        break;
                    }
                }
                res = ValidarMedico.ValidarObjetoMedico(medico);
                if (res == 1)
                    return medico;
                return null;
            }
            catch (ListaMedicosException ex)
            {
                throw ex;    
            }
            
        }

        public static List<Medico> ObterMedicoFiltro(ESPECIALIDADE esp)
        {
            List<Medico> lista = null;
            int contador_ = 0;
            foreach (Medico m in medicos)
            {
                if (m.Especialidade.Equals(esp))
                {
                    lista.Add(m);
                    contador_ ++;
                }
            }
            if (contador_ == 0)
                return null;

            return lista;
        }
        public static List<MiniMedico> ObterMiniMedicoFiltro(ESPECIALIDADE esp)
        {
            List<Medico> listaFiltro = null;
            int contador_=0;
            foreach(Medico m in medicos)
            {
                if (m.Especialidade.Equals(esp)) 
                { 
                    listaFiltro.Add(m);
                    contador_++;
                }
            }

            if (contador_ == 0)
                return null;

            List<MiniMedico> lista = new List<MiniMedico>();

            foreach(Medico medico in listaFiltro)
            {                
                lista.Add(new MiniMedico(medico.Nome, medico.CRM));
            }
            return lista;
        }

        public static Medico ObterMedico(int crm)
        {
            try {
                return FindMedico(crm);
            } catch (ListaMedicosException) 
            { 
                throw;
            } 
        }

        public static int OrganizarMedicosAlfabeticamente()
        {   
            int resultado = ValidarListaMedicos.ValidarLista();

            if (resultado != 1)
                return resultado;
            try {
            medicos.Sort(); //usa o metodo implementado em Medico para organizar alfabeticamente
            }catch(MedicoException me)
            {
                throw me;
            }
            return 1;
        }

        /// <summary>
        /// Retorna o número total de médicos na lista.
        /// </summary>
        public static int Contador
        {
            get { return contador; }
        }
        #endregion

        #endregion
    }
}
